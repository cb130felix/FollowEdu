<html>
    <head>
        <link href="/FollowEdu/css/bootstrap.min.css?ver=0.11.2" rel="stylesheet">
        
    </head>
    <body>
<!--         <h1>Esse serviço se encontra temporariamente indisponível.</h1> -->
        
            <h1> Serviços disponíveis </h1>
            <ul>
                
                <li><a href = "atividadecomp/atividade_complementar.php">Atividade Complementar(Curso de administração)</a></li>
                <li><a href = "historicoEscolar/principal.php">Solicitação de Histórico Escolar</a></li>
                <li><a href = "certificadoConclusao/principal.php">Solicitação de Certificado de Conclusão de curso</a></li>

            </ul>
        
        
    </body>
</html>
